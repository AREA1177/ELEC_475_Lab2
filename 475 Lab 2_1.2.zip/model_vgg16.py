"""
model_vgg16.py
ELEC 475 Lab 2 – VGG16-based SnoutNet (Regression)
Completely independent model variant — no shared weights or layers with AlexNet.
"""

import torch
import torch.nn as nn
from torchvision import models


class SnoutNetVGG16(nn.Module):
    def __init__(self, pretrained=True):
        super(SnoutNetVGG16, self).__init__()

        # Load a *fresh* pretrained VGG16 backbone (no reuse)
        vgg = models.vgg16(weights=models.VGG16_Weights.IMAGENET1K_V1 if pretrained else None)

        # Keep only the convolutional feature extractor
        self.features = nn.Sequential(*list(vgg.features.children()))

        # Define an independent regression head (not reusing VGG classifier)
        self.regressor = nn.Sequential(
            nn.Flatten(),
            nn.Linear(512 * 7 * 7, 2048),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(2048, 512),
            nn.ReLU(inplace=True),
            nn.Linear(512, 2)  # predict (x, y)
        )

        # Initialize only the new layers (no sharing)
        self._initialize_weights()

    def forward(self, x):
        x = self.features(x)
        x = self.regressor(x)
        return x

    def _initialize_weights(self):
        """Initialize regressor layers with Xavier initialization (not pretrained)."""
        for m in self.regressor:
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.constant_(m.bias, 0)
