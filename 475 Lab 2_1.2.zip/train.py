"""
train_vgg16.py
ELEC 475 Lab 2 – Train SnoutNet (VGG16 Backbone) with Data Augmentations
Trains only the VGG16 variant independently under multiple augmentation modes.
"""

import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

from dataset import PetNoseDataset, get_transforms
from model_vgg16 import SnoutNetVGG16  # independent VGG16 model


# ==================== CONFIG ====================
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
BATCH_SIZE = 16
EPOCHS = 25
LR = 1e-4

IMG_DIR = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\images-original\images"
TRAIN_ANN = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\train_noses.txt"
TEST_ANN  = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\test_noses.txt"
# ================================================


def train_vgg16(augment_mode="none"):
    """Train a VGG16-based SnoutNet under the specified augmentation setting."""
    model = SnoutNetVGG16(pretrained=True).to(DEVICE)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)

    # Datasets and loaders
    train_dataset = PetNoseDataset(IMG_DIR, TRAIN_ANN, get_transforms(augment=True, mode=augment_mode))
    val_dataset = PetNoseDataset(IMG_DIR, TEST_ANN, get_transforms(augment=False))
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, pin_memory=True, num_workers=2)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, pin_memory=True, num_workers=2)

    train_losses, val_losses = [], []

    print(f"\n=== Training VGG16 | Augmentation: {augment_mode.upper()} ===")
    print(f"Device: {DEVICE}")

    # ----------------- TRAINING LOOP -----------------
    for epoch in range(EPOCHS):
        model.train()
        running_loss = 0.0

        for images, targets in train_loader:
            images, targets = images.to(DEVICE, non_blocking=True), targets.to(DEVICE, non_blocking=True)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * images.size(0)

        train_loss = running_loss / len(train_loader.dataset)

        # ----------------- VALIDATION -----------------
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for images, targets in val_loader:
                images, targets = images.to(DEVICE, non_blocking=True), targets.to(DEVICE, non_blocking=True)
                outputs = model(images)
                loss = criterion(outputs, targets)
                val_loss += loss.item() * images.size(0)
        val_loss /= len(val_loader.dataset)

        train_losses.append(train_loss)
        val_losses.append(val_loss)

        print(f"Epoch [{epoch+1}/{EPOCHS}]  Train: {train_loss:.4f} | Val: {val_loss:.4f}")

    # ----------------- SAVE MODEL -----------------
    model_filename = f"snoutnet_vgg16_{augment_mode.lower()}.pth"
    torch.save(model.state_dict(), model_filename)
    print(f"✅ Saved model: {model_filename}")

    # ----------------- PLOT LOSS -----------------
    plt.figure(figsize=(7, 5))
    plt.plot(train_losses, label="Train")
    plt.plot(val_losses, label="Validation")
    plt.title(f"VGG16 – Loss Curve ({augment_mode})")
    plt.xlabel("Epoch")
    plt.ylabel("MSE Loss")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(f"loss_vgg16_{augment_mode.lower()}.png")
    plt.close()

    print(f"📉 Saved loss curve: loss_vgg16_{augment_mode.lower()}.png\n")


if __name__ == "__main__":
    augment_modes = ["none", "flip", "rotate", "combined"]

    for mode in augment_modes:
        train_vgg16(augment_mode=mode)
