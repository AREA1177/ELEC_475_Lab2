"""
compare_models.py
ELEC 475 Lab 2 – Step 6: Compare SnoutNet Models with Different Augmentations
Evaluates multiple trained models on the test partition and summarizes localization accuracy.
"""

import os
import torch
import numpy as np
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

from model import SnoutNet
from dataset import PetNoseDataset, get_transforms


# ===================== CONFIG =====================
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
BATCH_SIZE = 16

IMG_DIR = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\images-original\images"
TEST_ANN = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\test_noses.txt"

# List all models to evaluate
MODEL_CONFIGS = {
    "none": "snoutnet_none.pth",
    "flip": "snoutnet_flip.pth",
    "rotate": "snoutnet_rotate.pth",
    "combined": "snoutnet_combined.pth",
}
# ==================================================


def euclidean_distance(pred, target):
    """Compute Euclidean distance for each sample."""
    return torch.sqrt(torch.sum((pred - target) ** 2, dim=1))


def evaluate_model(model_path, test_loader):
    model = SnoutNet().to(DEVICE)
    model.load_state_dict(torch.load(model_path, map_location=DEVICE))
    model.eval()

    distances = []
    with torch.no_grad():
        for images, targets in test_loader:
            images, targets = images.to(DEVICE), targets.to(DEVICE)
            preds = model(images)
            dists = euclidean_distance(preds, targets)
            distances.extend(dists.cpu().numpy())

    distances = np.array(distances)
    stats = {
        "min": np.min(distances),
        "mean": np.mean(distances),
        "max": np.max(distances),
        "std": np.std(distances),
    }
    return stats, distances


def plot_histogram(distances, mode):
    plt.figure(figsize=(6, 4))
    plt.hist(distances, bins=40, color='lightcoral', edgecolor='black')
    plt.title(f"Error Distribution – Augmentation: {mode}")
    plt.xlabel("Euclidean Distance (pixels)")
    plt.ylabel("Frequency")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(f"error_hist_{mode}.png")
    plt.close()


def main():
    print(f"Using device: {DEVICE}\n")

    # Load test data
    test_dataset = PetNoseDataset(
        root_dir=IMG_DIR,
        annotations_file=TEST_ANN,
        transform=get_transforms(augment=False)
    )
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

    results = {}

    print("Evaluating all trained models...\n")

    for mode, model_path in MODEL_CONFIGS.items():
        if not os.path.exists(model_path):
            print(f"⚠️ Model not found: {model_path} (skipping)\n")
            continue

        print(f"▶ Evaluating {mode.upper()} model...")
        stats, distances = evaluate_model(model_path, test_loader)
        results[mode] = stats
        plot_histogram(distances, mode)
        print(f"  Min: {stats['min']:.3f} | Mean: {stats['mean']:.3f} | Max: {stats['max']:.3f} | Std: {stats['std']:.3f}\n")

    print("✅ Evaluation complete.\n")

    # ---- Print Summary Table ----
    print("📊 Localization Accuracy Summary:")
    print(f"{'Augmentation':<10} {'Min':>8} {'Mean':>8} {'Max':>8} {'Std':>8}")
    print("-" * 44)
    for mode, s in results.items():
        print(f"{mode:<10} {s['min']:>8.2f} {s['mean']:>8.2f} {s['max']:>8.2f} {s['std']:>8.2f}")

    # ---- Save to file ----
    with open("snoutnet_comparison_results.txt", "w") as f:
        f.write("Augmentation,Min,Mean,Max,Std\n")
        for mode, s in results.items():
            f.write(f"{mode},{s['min']:.4f},{s['mean']:.4f},{s['max']:.4f},{s['std']:.4f}\n")

    print("\nResults saved to snoutnet_comparison_results.txt")
    print("Error histograms saved as error_hist_<mode>.png")


if __name__ == "__main__":
    main()
