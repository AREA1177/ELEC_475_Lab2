"""
test.py
ELEC 475 Lab 2 – Step 4: Testing and Localization Accuracy Evaluation
"""

import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import numpy as np
import matplotlib.pyplot as plt

from model import SnoutNet
from dataset import PetNoseDataset, get_transforms


# ========== CONFIG ==========
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
BATCH_SIZE = 16

IMG_DIR = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\images-original\images"
TEST_ANN = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\\test_noses.txt"
MODEL_PATH = "snoutnet_model.pth"
# =============================


def euclidean_distance(pred, target):
    """Compute Euclidean distance for each sample."""
    return torch.sqrt(torch.sum((pred - target) ** 2, dim=1))


def evaluate_model(model, dataloader):
    model.eval()
    distances = []

    with torch.no_grad():
        for images, targets in dataloader:
            images, targets = images.to(DEVICE), targets.to(DEVICE)
            outputs = model(images)
            dists = euclidean_distance(outputs, targets)
            distances.extend(dists.cpu().numpy())

    distances = np.array(distances)
    stats = {
        "min": np.min(distances),
        "max": np.max(distances),
        "mean": np.mean(distances),
        "std": np.std(distances),
    }
    return stats, distances


def plot_error_histogram(distances):
    plt.figure(figsize=(7, 4))
    plt.hist(distances, bins=40, color='skyblue', edgecolor='black')
    plt.title("SnoutNet Localization Error Distribution")
    plt.xlabel("Euclidean Distance (pixels)")
    plt.ylabel("Frequency")
    plt.grid(alpha=0.4)
    plt.tight_layout()
    plt.savefig("snoutnet_error_hist.png")
    plt.show()


def main():
    print(f"Using device: {DEVICE}")

    # ---------- Load dataset ----------
    test_dataset = PetNoseDataset(
        root_dir=IMG_DIR,
        annotations_file=TEST_ANN,
        transform=get_transforms(augment=False)
    )
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

    # ---------- Load model ----------
    model = SnoutNet().to(DEVICE)
    model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
    print(f"Loaded trained model from {MODEL_PATH}")

    # ---------- Evaluate ----------
    print("Evaluating model on test partition...\n")
    stats, distances = evaluate_model(model, test_loader)

    print("📊 Localization Accuracy Statistics:")
    for k, v in stats.items():
        print(f"  {k:<5}: {v:.4f}")

    # ---------- Save histogram ----------
    plot_error_histogram(distances)


if __name__ == "__main__":
    main()
