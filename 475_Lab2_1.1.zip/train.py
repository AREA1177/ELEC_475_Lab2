"""
train_augmented.py
ELEC 475 Lab 2 – Step 5: Train with Augmentations
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from dataset import PetNoseDataset, get_transforms
from model import SnoutNet
import matplotlib.pyplot as plt

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
BATCH_SIZE = 16
EPOCHS = 25
LR = 1e-4

IMG_DIR = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\images-original\images"
TRAIN_ANN = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\train_noses.txt"
TEST_ANN  = r"C:\Users\Aidan\PycharmProjects\475 Lab 2\oxford-iiit-pet-noses\test_noses.txt"


def train_model(augment_mode="none"):
    model = SnoutNet().to(DEVICE)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)

    # Load datasets
    train_dataset = PetNoseDataset(IMG_DIR, TRAIN_ANN, get_transforms(augment=True, mode=augment_mode))
    val_dataset = PetNoseDataset(IMG_DIR, TEST_ANN, get_transforms(augment=False))
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

    train_losses, val_losses = [], []

    print(f"\n=== Training SnoutNet with augmentation: {augment_mode.upper()} ===")

    for epoch in range(EPOCHS):
        model.train()
        running_loss = 0.0
        for images, targets in train_loader:
            images, targets = images.to(DEVICE), targets.to(DEVICE)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * images.size(0)
        train_loss = running_loss / len(train_loader.dataset)

        # Validation
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for images, targets in val_loader:
                images, targets = images.to(DEVICE), targets.to(DEVICE)
                outputs = model(images)
                loss = criterion(outputs, targets)
                val_loss += loss.item() * images.size(0)
        val_loss /= len(val_loader.dataset)

        train_losses.append(train_loss)
        val_losses.append(val_loss)
        print(f"Epoch [{epoch+1}/{EPOCHS}]  Train: {train_loss:.4f}  |  Val: {val_loss:.4f}")

    torch.save(model.state_dict(), f"snoutnet_{augment_mode}.pth")
    print(f"✅ Model saved: snoutnet_{augment_mode}.pth")

    # Plot losses
    plt.figure(figsize=(7,5))
    plt.plot(train_losses, label="Train")
    plt.plot(val_losses, label="Validation")
    plt.title(f"Loss Curve – Augmentation: {augment_mode}")
    plt.xlabel("Epoch")
    plt.ylabel("MSE Loss")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"loss_{augment_mode}.png")
    plt.show()


if __name__ == "__main__":
    for mode in ["none", "flip", "rotate", "combined"]:
        train_model(augment_mode=mode)
